# sp18-hw1

UCSD Spring 2018 HW1 starter code

# Student 1
Name: Sha Liu
PID: A53239717

# Student 2 (optional, if in a group of 2)
Name:
PID:
